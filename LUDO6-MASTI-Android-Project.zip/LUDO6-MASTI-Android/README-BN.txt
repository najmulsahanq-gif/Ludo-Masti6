LUDO6 MASTI — Android APK project

এই ZIP-এ Android অ্যাপের সোর্স প্রজেক্ট আছে; তৈরি APK এখনো নেই। এই পরিবেশে Android SDK দিয়ে APK কম্পাইল করা সম্ভব হয়নি। GitHub Actions দিয়ে বিনা খরচে APK তৈরি করা যাবে।

ফোন দিয়ে APK তৈরির সহজ ধাপ:
1. ZIP ফাইলটি Extract করুন।
2. github.com-এ সাইন ইন করে New repository তৈরি করুন; নাম দিন LUDO6-MASTI। Public বা Private যেকোনোটি হতে পারে।
3. Extract করা ফোল্ডারের ভেতরের সব ফাইল GitHub repository-তে Upload files দিয়ে আপলোড করুন। .github ফোল্ডারটিও অবশ্যই আপলোড করতে হবে।
4. Commit changes চাপুন।
5. Repository-র Actions ট্যাবে যান। “Build LUDO6 MASTI APK” workflow খুলে Run workflow চাপুন (অথবা push-এর পর চলা workflow-তে ক্লিক করুন)।
6. কাজ শেষ হলে workflow run-এর নিচে Artifacts থেকে LUDO6-MASTI-APK ডাউনলোড করুন। ZIP খুললে app-debug.apk পাবেন।
7. APK ফোনে ডাউনলোড করে ট্যাপ করুন। Android অনুমতি চাইলে শুধু আপনার ডাউনলোড করা APK ইনস্টল করার অনুমতি দিন, তারপর Install চাপুন।

নোট:
- এটি debug APK, Play Store-এ প্রকাশের জন্য signed release APK নয়।
- এই গেমটি বর্তমানে একই ফোনে লোকাল/পালাক্রমে খেলার প্রোটোটাইপ। অনলাইনে দূরের বন্ধুর সঙ্গে খেলার সার্ভার এতে নেই।
- বাংলা ভয়েস Android WebView-এর Text-to-Speech/ব্রাউজার সমর্থনের ওপর নির্ভর করতে পারে।
